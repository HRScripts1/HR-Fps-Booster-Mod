package com.hr.fpsboost;


import net.fabricmc.api.ClientModInitializer;
import net.minecraft.client.MinecraftClient;
import net.minecraft.particle.ParticleStatus;

public final class HRFpsBooster implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        MinecraftClient client = MinecraftClient.getInstance();
        // Conservative, widely compatible automatic optimization: reduce particle load.
        client.options.getParticles().setValue(ParticleStatus.MINIMAL);
        client.options.write();
        System.out.println("[HR FPS Booster] Automatic FPS-friendly settings applied.");
    }
}
